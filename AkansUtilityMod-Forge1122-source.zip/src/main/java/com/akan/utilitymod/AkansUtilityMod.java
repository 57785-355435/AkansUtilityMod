package com.akan.utilitymod;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import net.minecraftforge.common.config.Configuration;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.FMLCommonHandler;
import net.minecraftforge.fml.common.eventhandler.EventPriority;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import net.minecraftforge.event.world.BlockEvent;
import net.minecraftforge.event.world.WorldEvent;
import net.minecraftforge.event.furnace.FurnaceFuelBurnTimeEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ResourceLocation;
import net.minecraft.block.Block;
import net.minecraft.block.state.IBlockState;
import net.minecraft.tileentity.TileEntityFurnace;
import net.minecraftforge.fml.common.Loader;
import net.minecraftforge.fml.common.registry.ForgeRegistries;
import net.minecraftforge.event.RegistryEvent;
import net.minecraftforge.event.entity.living.LivingDropsEvent;
import net.minecraft.entity.item.EntityItem;
import java.io.File;
import java.lang.reflect.Method;
import java.util.List;
import java.util.Random;

@Mod(modid = AkansUtilityMod.MODID, name = "Akan's Utility Mod", version = "0.1.0",
     acceptedMinecraftVersions = "[1.12.2]", dependencies = "after:ic2;after:tconstruct;after:appliedenergistics2;after:botania;after:enderio;after:avaritia;after:storagedrawers;after:jei")
public class AkansUtilityMod {
    public static final String MODID = "akansutilitymod";
    private static Configuration config;
    private static boolean slowBurn = true, instantSmelt = true, multiplyDrops = true;
    private static int burnMultiplier = 10, dropMultiplier = 10;

    @Mod.EventHandler
    public void preInit(FMLPreInitializationEvent event) {
        config = new Configuration(new File(event.getModConfigurationDirectory(), MODID + ".cfg"));
        loadConfig();
        net.minecraftforge.common.MinecraftForge.EVENT_BUS.register(this);
        FMLCommonHandler.instance().bus().register(this);
    }

    private static void loadConfig() {
        slowBurn = config.getBoolean("slowBurn", "general", true, "Multiply furnace fuel burn duration by this setting.");
        instantSmelt = config.getBoolean("instantSmelt", "general", true, "Try to make furnace smelting instant.");
        multiplyDrops = config.getBoolean("multiplyDrops", "general", true, "Multiply ordinary block drops.");
        burnMultiplier = config.getInt("burnMultiplier", "general", 10, 1, 1000, "Fuel burn duration multiplier.");
        dropMultiplier = config.getInt("dropMultiplier", "general", 10, 1, 64, "Block drop multiplier. Large values may lag or overflow.");
        if (config.hasChanged()) config.save();
    }

    @SubscribeEvent
    public void fuel(FurnaceFuelBurnTimeEvent event) {
        if (slowBurn && event.getBurnTime() > 0) {
            long v = (long) event.getBurnTime() * burnMultiplier;
            event.setBurnTime((int)Math.min(Integer.MAX_VALUE, v));
        }
    }

    @SubscribeEvent(priority = EventPriority.LOWEST)
    public void drops(BlockEvent.HarvestDropsEvent event) {
        if (!multiplyDrops || event.getWorld().isRemote || event.getDrops().isEmpty()) return;
        List<ItemStack> drops = event.getDrops();
        Random rand = event.getWorld().rand;
        int originalSize = drops.size();
        for (int i = 0; i < originalSize; i++) {
            ItemStack stack = drops.get(i);
            if (stack.isEmpty()) continue;
            // Keep original stack and add copies; cap prevents unbounded entity spam.
            int total = Math.min(4096, stack.getCount() * dropMultiplier);
            stack.setCount(Math.min(stack.getMaxStackSize(), total));
            int remaining = total - stack.getCount();
            while (remaining > 0 && drops.size() < 256) {
                int n = Math.min(stack.getMaxStackSize(), remaining);
                drops.add(stack.copy());
                drops.get(drops.size()-1).setCount(n);
                remaining -= n;
            }
        }
    }

    // Forge 1.12.2 has no safe general event to change every furnace recipe duration.
    // Instant-smelting is therefore deliberately left as a documented TODO rather than
    // falsely claiming that this event-based prototype implements it.
}
